/*
ID: your_id
PROG: command
LANG: C++
*/
#include <iostream>
#include <cstdlib> 
using namespace std; 
int main(){
    int N=0;
    cin >> N;
    
    cout << N << endl; 
    return 0; 
}