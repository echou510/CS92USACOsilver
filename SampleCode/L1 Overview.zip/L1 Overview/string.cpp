/*
ID: your_id
PROG: string
LANG: C++
*/
#include <iostream>
#include <fstream> 
#include <sstream> 
#include <cstdlib>
using namespace std; 
template <typename T> string str(const T& n){
 ostringstream stm; stm << n; return stm.str() ;
}
int main(){
    ifstream fin("a.in");
    ofstream fout("a.out");
    string s("");
    fin >> s;
    fout << s << endl; 
    fin.close();
    fout.close(); 
    return 0; 
}