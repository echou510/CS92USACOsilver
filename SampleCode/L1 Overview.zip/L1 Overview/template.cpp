/*
ID: your_id
PROG: template
LANG: C++
*/
#include <iostream>
#include <fstream> 
#include <cstdlib>
using namespace std; 
int main(){
    ifstream fin("a.in");
    ofstream fout("a.out");
    int N=0;
    fin >> N;
    
    fout << N << endl; 
    fin.close();
    fout.close(); 
    return 0; 
}