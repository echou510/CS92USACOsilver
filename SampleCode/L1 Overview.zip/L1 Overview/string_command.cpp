/*
ID: your_id
PROG: string_command
LANG: C++
*/
#include <iostream>
#include <cstdlib>
#include <sstream>  
#include <string> 
using namespace std; 
template <typename T> string str(const T& n){
 ostringstream stm; stm << n; return stm.str() ;
}
int main(){
    string s(""); 
    cin >> s;  
    cout << s << endl; 
    return 0; 
}