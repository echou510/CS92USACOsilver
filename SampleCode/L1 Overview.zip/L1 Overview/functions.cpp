/*
ID: your_id
PROG: functions
LANG: C++
*/
#include <iostream>
#include <cstdlib>
#include <sstream>  
#include <string> 
#include <vector> 
using namespace std; 
template <typename T> string str(const T& n){
 ostringstream stm; stm << n; return stm.str() ;
}
typedef vector<int> vi; 
typedef vector<string> vs; 

int main(){
    string s(""); 
    cin >> s;  
    cout << s << endl; 
    return 0; 
}