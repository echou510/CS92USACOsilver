#define FILEMODE
#define PROJECT "citystate"

#include <bits/stdc++.h>
using namespace std;
typedef long long lint;
typedef vector<lint> vlint; 
typedef vector<int> vi;  
typedef vector<string> vs;  
#define MAXINT 2147483647
#define MININT -2147483648
#define MOD 1000000007
#define pb push_back
#define mp make_pair
#define space << " " <<
#define spacef << " "
#define newline << "\n"
#define fo(i,a,b) for(lint i = a; i <= b; i++)
#define foo(i,a,b,d) for(lint i = a; i <= b; i+=d)
#define print(x) for(auto i : x) cout << i spacef
#define println(x) for(auto i: x) cout << i spacef; cout newline; 
#define len(x) sizeof(x)/sizeof(x[0])
#define reset(x, n) for (int i=0; i<n; i++) x[i]=0; 
#define mmax(x,i) x = max(x,i)
#define mmin(x,i) x = min(x,i)

int main() {
	#ifdef FILEMODE
      freopen(PROJECT ".in", "r", stdin);
	  freopen(PROJECT ".out", "w", stdout);
    #endif

	lint n, ans = 0;
	cin >> n;
	string s, t;
	map<string, lint> city;

	fo(i, 0, n-1) {
		cin >> s >> t;
		s = s.substr(0, 2);
		string code = s + t;
		if (s != t)ans += city[code];
		city[t + s]++;
	}
 
	cout << ans;
	return 0;
}