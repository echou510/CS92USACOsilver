/*
ID: echou511
PROG: frac1
LANG: C++
*/

#include <bits/stdc++.h>

using namespace std;

struct frac{
    int a; // a is nominator
    int b; // b is denominator

    frac(int x, int y){ 
        a = x; b = y; 
        reduce(); 
    }
    int gcd(int m, int n){
        while (n!=0){ // n==0, you get your gcd
            int oldm = m; 
            m = n;         // quotient
            n = oldm % n;  // remainder
         }
        return m; 
    }
    void reduce(){
        int gcf = gcd(a, b); 
        a = a / gcf; 
        b = b / gcf; 
    }

    double value(){
        return (double) a/(double) b; 
    }

    bool operator==(frac &other){
        return a == other.a && b == other.b;  
    }
    bool operator!=(frac &other){
        return a != other.a || b != other.b;  
    }
    bool operator>(frac &other){
        return value() > other.value(); 
    }
    bool operator>=(frac &other){
        return value() >= other.value(); 
    }
    bool operator<(frac &other){
        return value() < other.value(); 
    }
    bool operator<=(frac &other){
        return value() <= other.value(); 
    }
    void display(){
        cout << a << "/" << b << endl; 
    }
}; 

void print_fractions(vector<frac> f){
  for (int i=0; i<f.size(); i++){
    f[i].display(); 
  }
}

int linear_search(vector<frac> f, frac key){
   int i=0; 
   while (i<f.size() && key > f[i]) i++; 
   return i; 
}
int main() {
    ifstream fin("frac1.in");
    ofstream fout("frac1.out");

    int N;
    fin >> N;
    vector<frac> fractions;
    fractions.push_back(frac(0, 1));
    fractions.push_back(frac(1, 1));   

    for (int b=1; b<=N; b++){
       for (int a=1; a<b; a++){
           frac f(a, b); 
           int idx = linear_search(fractions, f); 
           if (f != fractions[idx]){
              fractions.insert(fractions.begin() + idx, f);
           }
       }
    }
    // print_fractions(fractions); 
    for (int i=0; i<fractions.size(); i++){
        int s = fractions[i].a; int t = fractions[i].b; 
        fout << s << "/" << t << endl;  
      }
    fin.close(); 
    fout.close(); 

    return 0;
}

/*
    cout << N  << endl; 
    
    int a, b; 
    cout << "Enter a: "; 
    cin >> a; 
    cout << "Enter b: "; 
    cin >> b; 
    frac t(a, b); 
    t.display(); 
    */