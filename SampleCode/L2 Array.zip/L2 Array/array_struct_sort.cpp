#include <bits/stdc++.h>
using namespace std; 
template <typename T> string str(const T& n){
 ostringstream stm; stm << n; return stm.str() ;
}

struct data{
    int num1;
    int num2;
    bool operator<(const data& other) const { return num1 < other.num1; }
    string to_string(){ return "("+str(num1)+", "+str(num2)+")"; }
};

int main(){
   int N=5; 
   data array[N] = {{3, 5}, {5, 2}, {4, 1}, {2, 3}, {1, 4}};
   cout << "{";
   for (int i=0; i<N; i++){ cout << array[i].to_string() << " "; }
   cout << "}" << endl;
   
   sort(array, array+N);
   
   cout << "{";
   for (int i=0; i<N; i++){ cout << array[i].to_string() << " "; }
   cout << "}" << endl;
}