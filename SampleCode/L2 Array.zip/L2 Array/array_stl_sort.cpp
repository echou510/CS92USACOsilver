#include <iostream>
#include <array> 
#include <string> 
#include <algorithm> 
using namespace std; 

int main(){
    array<string, 4> colors = {"blue", "black", "red", "green"};
    for (string color: colors){ cout << color << " ";  } 
    cout << endl; 
    sort(colors.begin(), colors.end()); 
    for (string color: colors){ cout << color << " ";  }
    cout << endl; 
    return 0; 
}