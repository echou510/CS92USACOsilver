/*
ID: echou511
TASK: castle
LANG: C++                 
*/
#include <bits/stdc++.h> 
using namespace std;
typedef vector<int> vi; 
typedef vector<vector<int>> vii;

vii grid;  // 2D array of N row, M column with all 0s. 
vii visited; // visited. 

void printMatrix( vii grid ){
   for (int i=0; i<grid.size(); i++){
    for (int j=0; j<grid[i].size(); j++){
        if (j==0) cout << grid[i][j]; 
        else cout << " " << grid[i][j];
     }
     cout << endl; 
   }
}

int dfs(int r, int c, int color){
   if (r <0 || r >=grid.size() || c<0 || c >= grid[0].size() || visited[r][c]) 
      return 0;  // total number in this room is 0. 
   int size = 1; 
   visited[r][c] = color; 

   if (!(grid[r][c] & 1)) size += dfs(r, c-1, color); // west
   if (!(grid[r][c] & 2)) size += dfs(r-1, c, color); // north
   if (!(grid[r][c] & 4)) size += dfs(r, c+1, color); // east
   if (!(grid[r][c] & 8)) size += dfs(r+1, c, color); // south

   return size; 
}

int main() {
    ifstream fin("castle.in");
    ofstream fout("castle.out");
    int M, N; 
    fin >> M; 
    fin >> N; 
    
    grid.assign(N, vi(M, 0)); 
    visited.assign(N, vi(M, 0)); 

    for (int r=0; r<N; r++){
        for (int c=0; c<M; c++){
            fin >> grid[r][c]; 
        }
    }

    int number_room = 0; 
    int max_room =0; 
    
    for (int r=0; r<N; r++){
        for (int c=0; c<M; c++){
          if (visited[r][c] == 0){
             number_room++; 
             int size = dfs(r, c, number_room); 

             if (size > max_room) max_room = size; 
          }
        }
    }
    
    fout << number_room << endl; 
    fout << max_room << endl; 

    //printMatrix(visited); 
    //cout << endl; 

    int mr = -1; 
    int mc = -1; 
    int max_new_room = max_room;
    string dir = " "; 

    for (int c = 0; c<M; c++){
        for (int r=N-1; r>=0; r--){
          visited.assign(N, vi(M, 0)); // reset visited
          if ((grid[r][c] & 2)) { 
            grid[r][c] &= ~2; 
            int size = dfs(r, c, 100); 
            grid[r][c] |= 2; 
            if (size > max_new_room){
                mr = r; mc = c; dir = "N"; max_new_room = size; 
            }
          }
          visited.assign(N, vi(M, 0)); // reset visited
          if ((grid[r][c] & 4)) { 
            grid[r][c] &= ~4; 
            int size = dfs(r, c, 100); 
            grid[r][c] |= 4; 
            if (size > max_new_room){
                mr = r; mc = c; dir = "E"; max_new_room = size; 
            }
          }
        }
    }
    fout << max_new_room << endl; 
    fout << (mr+1) << " " << (mc+1) << " " << dir << endl; 
    fin.close();
    fout.close();
    return 0;
}