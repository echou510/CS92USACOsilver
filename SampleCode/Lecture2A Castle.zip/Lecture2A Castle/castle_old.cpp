#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int m, n;
    cin >> m >> n;

    vector<vector<int>> grid(n, vector<int>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> grid[i][j];
        }
    }

    vector<vector<int>> visited(n, vector<int>(m, 0));
    int room_count = 0;
    int max_room_size = 0;

    function<int(int, int)> dfs = [&](int r, int c) {
        if (r < 0 || r >= n || c < 0 || c >= m || visited[r][c]) {
            return 0;
        }
        visited[r][c] = 1;
        int size = 1;

        if (!(grid[r][c] & 1)) size += dfs(r, c - 1);  // West
        if (!(grid[r][c] & 2)) size += dfs(r - 1, c);  // North
        if (!(grid[r][c] & 4)) size += dfs(r, c + 1);  // East
        if (!(grid[r][c] & 8)) size += dfs(r + 1, c);  // South
        return size;
    };

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (!visited[i][j]) {
                room_count++;
                max_room_size = max(max_room_size, dfs(i, j));
            }
        }
    }

    cout << room_count << endl;
    cout << max_room_size << endl;

    int best_r = -1, best_c = -1, best_size = -1;
    char best_dir = ' ';

    for (int c = 0; c < m; ++c) {
        for (int r = n - 1; r >= 0; --r) {
            
            visited.assign(n, vector<int>(m, 0));
            int current_room_size;

            if (r > 0 && (grid[r][c] & 2)) {
                grid[r][c] &= ~2;
                current_room_size = dfs(r,c);
                grid[r][c] |= 2;

                if(current_room_size > best_size){
                    best_size = current_room_size;
                    best_r = r;
                    best_c = c;
                    best_dir = 'N';
                }
            }

            visited.assign(n, vector<int>(m, 0));
            if (c < m - 1 && (grid[r][c] & 4)) {
                grid[r][c] &= ~4;
                current_room_size = dfs(r,c);
                grid[r][c] |= 4;
                if(current_room_size > best_size){
                    best_size = current_room_size;
                    best_r = r;
                    best_c = c;
                    best_dir = 'E';
                }
            }
        }
    }

    cout << best_size << endl;
    cout << best_r + 1 << " " << best_c + 1 << " " << best_dir << endl;

    return 0;
}